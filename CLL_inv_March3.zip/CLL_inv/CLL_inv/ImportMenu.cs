﻿using System;
using System.Windows.Forms;

namespace CLL_inv
{
    public partial class ImportMenu : Form
    {
        private Form previousForm;

        public ImportMenu(Form previous)
        {
            InitializeComponent();
            previousForm = previous;
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Close();  // Close the ImportMenu form
            previousForm.Show();  // Show the previous form (InvoiceMenu)
        }
    }
}
