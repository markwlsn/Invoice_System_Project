﻿using System;
using System.Windows.Forms;

namespace CLL_inv
{
    public partial class MainMenuForm : Form
    {
        private string username;

        public MainMenuForm(string user)
        {
            InitializeComponent();
            username = user;
        }

        private void UserBtn_Click(object sender, EventArgs e)
        {
            UserAccessForm userAccessForm = new UserAccessForm(this, username);
            userAccessForm.Show();
            this.Hide();
        }

        private void ClientBtn_Click(object sender, EventArgs e)
        {
            // Open ClientForm and pass MainMenuForm as previous form
            ClientForm clientForm = new ClientForm(this);
            clientForm.Show();
            this.Hide(); // Hide MainMenuForm to keep it in memory
        }


        private void InvoiceBtn_Click(object sender, EventArgs e)
        {
            // Pass this form as a reference to InvoiceMenu
            InvoiceMenu invoiceMenu = new InvoiceMenu(this);
            invoiceMenu.Show();
            this.Hide(); // Hide MainMenuForm to keep it in memory
        }

        private void LogoutBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 loginForm = new Form1();
            loginForm.Show();
        }

        private void MainMenuForm_Load(object sender, EventArgs e)
        {
            // You can add additional setup if necessary
        }
    }
}
