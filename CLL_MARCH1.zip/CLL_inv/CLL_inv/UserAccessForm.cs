﻿using System;
using System.Windows.Forms;

namespace CLL_inv
{
    public partial class UserAccessForm : Form
    {
        private Form previousForm;
        private string username;

        public UserAccessForm(Form prevForm, string user)
        {
            InitializeComponent();
            previousForm = prevForm;
            username = user;
        }

        private void UserAccessForm_Load(object sender, EventArgs e)
        {
            UserN.Text = "Logged in as: " + username;
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            previousForm.Show();
        }

        private void UserN_Click(object sender, EventArgs e)
        {
            // Add code to handle UserN label click
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {
            // Add code to handle panel2 paint event
        }

        private void UserLogoutBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 loginForm = new Form1();
            loginForm.Show();
        }
    }
}
