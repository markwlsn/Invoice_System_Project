﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace CLL_inv
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            UserF.Text = "Username";
            PassF.Text = "Password";
            UserF.ForeColor = Color.Gray;
            PassF.ForeColor = Color.Gray;

            UserF.Enter += new EventHandler(UserF_Enter);
            UserF.Leave += new EventHandler(UserF_Leave);
            PassF.Enter += new EventHandler(PassF_Enter);
            PassF.Leave += new EventHandler(PassF_Leave);

            this.KeyPreview = true;
            this.KeyPress += new KeyPressEventHandler(Form1_KeyPress);
        }

        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                LoginBtn_Click(sender, e);
            }
        }

        private void UserF_Enter(object sender, EventArgs e)
        {
            if (UserF.Text == "Username")
            {
                UserF.Text = "";
                UserF.ForeColor = Color.Black;
            }
        }

        private void UserF_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(UserF.Text))
            {
                UserF.Text = "Username";
                UserF.ForeColor = Color.Gray;
            }
        }

        private void PassF_Enter(object sender, EventArgs e)
        {
            if (PassF.Text == "Password")
            {
                PassF.Text = "";
                PassF.ForeColor = Color.Black;
                PassF.UseSystemPasswordChar = true;
            }
        }

        private void PassF_Leave(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(PassF.Text))
            {
                PassF.Text = "Password";
                PassF.ForeColor = Color.Gray;
                PassF.UseSystemPasswordChar = false;
            }
        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            string username = UserF.Text;
            string password = PassF.Text;

            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password) || username == "Username" || password == "Password")
            {
                MessageBox.Show("Both fields must be filled in!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (username == "admin" && password == "123")
                {
                    this.Hide();
                    MainMenuForm mainMenuForm = new MainMenuForm(username);
                    mainMenuForm.Show();
                }
                else
                {
                    MessageBox.Show("Invalid Username or Password", "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void UserF_TextChanged(object sender, EventArgs e)
        {
            // You can add code here if needed when the text is changed
        }

        private void PassF_TextChanged(object sender, EventArgs e)
        {
            // You can add code here if needed when the text is changed
        }
    }
}
