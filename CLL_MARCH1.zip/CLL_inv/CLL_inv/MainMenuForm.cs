﻿using System;
using System.Windows.Forms;

namespace CLL_inv
{
    public partial class MainMenuForm : Form
    {
        private string username;

        public MainMenuForm(string user)
        {
            InitializeComponent();
            username = user;
        }

        private void UserBtn_Click(object sender, EventArgs e)
        {
            UserAccessForm userAccessForm = new UserAccessForm(this, username);
            userAccessForm.Show();
            this.Hide();
        }

        private void ClientBtn_Click(object sender, EventArgs e)
        {
            // Open ClientForm
            ClientForm clientForm = new ClientForm();
            clientForm.Show();

            // Close the current form
            this.Close();
        }


        private void InvoiceBtn_Click(object sender, EventArgs e)
        {
            // Add code to handle Invoice button click
        }

        private void LogoutBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 loginForm = new Form1();
            loginForm.Show();
        }

        private void MainMenuForm_Load(object sender, EventArgs e)
        {
            // You can add additional setup if necessary
        }
    }
}
