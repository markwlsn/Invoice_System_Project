﻿namespace CLL_inv
{
    partial class UserAccessForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.BackBtn = new System.Windows.Forms.Button();
            this.UserN = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.UserLogoutBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BackBtn
            // 
            this.BackBtn.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackBtn.Location = new System.Drawing.Point(191, 455);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(200, 35);
            this.BackBtn.TabIndex = 1;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = true;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // UserN
            // 
            this.UserN.AutoSize = true;
            this.UserN.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserN.Location = new System.Drawing.Point(214, 419);
            this.UserN.Name = "UserN";
            this.UserN.Size = new System.Drawing.Size(44, 24);
            this.UserN.TabIndex = 2;
            this.UserN.Text = "label";
            this.UserN.Click += new System.EventHandler(this.UserN_Click);
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = global::CLL_inv.Properties.Resources.account_icon_8;
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel2.Location = new System.Drawing.Point(191, 230);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(200, 175);
            this.panel2.TabIndex = 3;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::CLL_inv.Properties.Resources.cll_logo;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(521, 196);
            this.panel1.TabIndex = 0;
            // 
            // UserLogoutBtn
            // 
            this.UserLogoutBtn.BackColor = System.Drawing.SystemColors.Control;
            this.UserLogoutBtn.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UserLogoutBtn.ForeColor = System.Drawing.Color.Firebrick;
            this.UserLogoutBtn.Location = new System.Drawing.Point(191, 496);
            this.UserLogoutBtn.Name = "UserLogoutBtn";
            this.UserLogoutBtn.Size = new System.Drawing.Size(200, 35);
            this.UserLogoutBtn.TabIndex = 4;
            this.UserLogoutBtn.Text = "Logout";
            this.UserLogoutBtn.UseVisualStyleBackColor = false;
            this.UserLogoutBtn.Click += new System.EventHandler(this.UserLogoutBtn_Click);
            // 
            // UserAccessForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(545, 546);
            this.Controls.Add(this.UserLogoutBtn);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.UserN);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.panel1);
            this.Name = "UserAccessForm";
            this.Text = "UserAccessForm";
            this.Load += new System.EventHandler(this.UserAccessForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button BackBtn;
        private System.Windows.Forms.Label UserN;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button UserLogoutBtn;
    }
}