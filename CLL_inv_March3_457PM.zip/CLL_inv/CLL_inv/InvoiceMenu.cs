﻿using System;
using System.Windows.Forms;

namespace CLL_inv
{
    public partial class InvoiceMenu : Form
    {
        private Form previousForm;

        public InvoiceMenu(Form previous)
        {
            InitializeComponent();
            previousForm = previous;
        }

        private void ImportBtn_Click(object sender, EventArgs e)
        {
            // Redirect to ImportMenu
            ImportMenu importMenu = new ImportMenu(this);
            importMenu.Show();
            this.Hide(); // Hide InvoiceMenu to keep it in memory
        }

        private void ExportBtn_Click(object sender, EventArgs e)
        {
            // Redirect to ExportMenu
            ExportMenu exportMenu = new ExportMenu(this);
            exportMenu.Show();
            this.Hide(); // Hide InvoiceMenu to keep it in memory
        }

        private void CompanyDetailsBtn_Click(object sender, EventArgs e)
        {
            // Redirect to CompD (Company Details) form
            CompD compD = new CompD(this);
            compD.Show();
            this.Hide(); // Hide InvoiceMenu to keep it in memory
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Close();  // Close the current InvoiceMenu form
            previousForm.Show();  // Show the previous form (MainMenuForm)
        }

        private void InvoiceMenu_Load(object sender, EventArgs e)
        {
            // Any necessary initialization
        }
    }
}
