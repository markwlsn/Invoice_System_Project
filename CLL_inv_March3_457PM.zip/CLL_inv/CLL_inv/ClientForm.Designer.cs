﻿namespace CLL_inv
{
    partial class ClientForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.SearchBarF = new System.Windows.Forms.TextBox();
            this.OptionCBox = new System.Windows.Forms.ComboBox();
            this.ClientDataView = new System.Windows.Forms.DataGridView();
            this.BackBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.ClientDataView)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackgroundImage = global::CLL_inv.Properties.Resources.cll_logo;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(857, 213);
            this.panel1.TabIndex = 0;
            // 
            // SearchBarF
            // 
            this.SearchBarF.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SearchBarF.Location = new System.Drawing.Point(12, 236);
            this.SearchBarF.Name = "SearchBarF";
            this.SearchBarF.Size = new System.Drawing.Size(516, 29);
            this.SearchBarF.TabIndex = 1;
            this.SearchBarF.TextChanged += new System.EventHandler(this.SearchBarF_TextChanged);
            // 
            // OptionCBox
            // 
            this.OptionCBox.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OptionCBox.FormattingEnabled = true;
            this.OptionCBox.Location = new System.Drawing.Point(534, 236);
            this.OptionCBox.Name = "OptionCBox";
            this.OptionCBox.Size = new System.Drawing.Size(254, 29);
            this.OptionCBox.TabIndex = 2;
            this.OptionCBox.SelectedIndexChanged += new System.EventHandler(this.OptionCBox_SelectedIndexChanged);
            // 
            // ClientDataView
            // 
            this.ClientDataView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ClientDataView.Location = new System.Drawing.Point(12, 274);
            this.ClientDataView.Name = "ClientDataView";
            this.ClientDataView.Size = new System.Drawing.Size(857, 330);
            this.ClientDataView.TabIndex = 3;
            this.ClientDataView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ClientDataView_CellContentClick);
            // 
            // BackBtn
            // 
            this.BackBtn.Font = new System.Drawing.Font("Franklin Gothic Medium Cond", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackBtn.Location = new System.Drawing.Point(794, 231);
            this.BackBtn.Name = "BackBtn";
            this.BackBtn.Size = new System.Drawing.Size(75, 37);
            this.BackBtn.TabIndex = 4;
            this.BackBtn.Text = "Back";
            this.BackBtn.UseVisualStyleBackColor = true;
            this.BackBtn.Click += new System.EventHandler(this.BackBtn_Click);
            // 
            // ClientForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(881, 616);
            this.Controls.Add(this.BackBtn);
            this.Controls.Add(this.ClientDataView);
            this.Controls.Add(this.OptionCBox);
            this.Controls.Add(this.SearchBarF);
            this.Controls.Add(this.panel1);
            this.Name = "ClientForm";
            this.Text = "ClientForm";
            this.Load += new System.EventHandler(this.ClientForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ClientDataView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox SearchBarF;
        private System.Windows.Forms.ComboBox OptionCBox;
        private System.Windows.Forms.DataGridView ClientDataView;
        private System.Windows.Forms.Button BackBtn;
    }
}