﻿using System;
using System.Windows.Forms;

namespace CLL_inv
{
    public partial class CompD : Form
    {
        private Form previousForm;

        public CompD(Form previous)
        {
            InitializeComponent();
            previousForm = previous;
        }

        private void CompD_Load(object sender, EventArgs e)
        {
            // Any necessary initialization
        }

        private void CreateBtn_Click(object sender, EventArgs e)
        {
            // Functionality for creating company details
        }

        private void SelectBtn_Click(object sender, EventArgs e)
        {
            // Functionality for selecting company details
        }

        private void ModifyBtn_Click(object sender, EventArgs e)
        {
            // Functionality for modifying company details
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            // Functionality for deleting company details
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Close();  // Close CompD (Company Details) form
            previousForm.Show();  // Show the previous form (InvoiceMenu)
        }

        private void CompanyData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Handle DataGridView cell click event if needed
        }
    }
}
