﻿using System;
using System.Windows.Forms;

namespace CLL_inv
{
    public partial class ExportMenu : Form
    {
        private Form previousForm;

        public ExportMenu(Form previous)
        {
            InitializeComponent();
            previousForm = previous;
        }

        private void ExportMenu_Load(object sender, EventArgs e)
        {
            // Any necessary initialization
        }

        private void ExportBtn_Click(object sender, EventArgs e)
        {
            // Add functionality for exporting
        }

        private void EditBtn_Click(object sender, EventArgs e)
        {
            // Add functionality for editing
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            // Add functionality for deleting
        }

        private void BackBtn_Click(object sender, EventArgs e)
        {
            this.Close();  // Close ExportMenu
            previousForm.Show();  // Show the previous form (InvoiceMenu)
        }
    }
}
