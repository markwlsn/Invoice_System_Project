﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;

namespace CLL_inv
{
    public partial class ClientForm : Form
    {
        private List<ClientRecord> allRecords = new List<ClientRecord>(); // Store all records

        public ClientForm()
        {
            InitializeComponent();
        }

        private void ClientForm_Load(object sender, EventArgs e)
        {
            InitializeComboBox();
            GenerateSampleData();
            DisplayAllData();
            FormatGridView();
        }

        private void InitializeComboBox()
        {
            OptionCBox.DropDownStyle = ComboBoxStyle.DropDownList;
            OptionCBox.Items.Add("Company Name");
            OptionCBox.Items.Add("Invoice No.");
            OptionCBox.Items.Add("By Date");
            OptionCBox.SelectedIndex = -1; // Ensure nothing is selected by default
        }

        private void GenerateSampleData()
        {
            allRecords = new List<ClientRecord>();

            int invoiceNumber = 1000;
            string[] companies = { "Tech Corp", "Alpha Ltd", "Beta Inc", "Gamma Co", "Delta Solutions",
                                   "Omega Ltd", "Sigma Enterprises", "Zeta Systems", "Epsilon Technologies", "Theta Solutions" };

            for (int month = 1; month <= 3; month++) // January to March
            {
                for (int day = 1; day <= 10; day++) // 10 entries per month
                {
                    allRecords.Add(new ClientRecord(invoiceNumber++, companies[(invoiceNumber / 100) % companies.Length], $"{month:D2}/{day:D2}/2025"));
                }
            }
        }

        private void DisplayAllData()
        {
            BindDataToGrid(allRecords);
        }

        private void BindDataToGrid(List<ClientRecord> records)
        {
            DataTable table = new DataTable();
            table.Columns.Add("Invoice No.");
            table.Columns.Add("Company Name");
            table.Columns.Add("Date");

            foreach (var record in records)
            {
                table.Rows.Add(record.InvoiceNo, record.CompanyName, record.Date.ToString("MM/dd/yyyy"));
            }

            ClientDataView.DataSource = table;
        }

        private void FormatGridView()
        {
            ClientDataView.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            ClientDataView.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            ClientDataView.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ClientDataView.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
            ClientDataView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            ClientDataView.AllowUserToAddRows = false;
        }

        // Real-time search triggered by typing
        private void SearchBarF_TextChanged(object sender, EventArgs e)
        {
            PerformSearch();
        }

        private void PerformSearch()
        {
            if (OptionCBox.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a search category from the dropdown list.", "Selection Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string searchCategory = OptionCBox.SelectedItem.ToString();
            string searchText = SearchBarF.Text.Trim();

            if (string.IsNullOrWhiteSpace(searchText))
            {
                // If search is empty, display all data
                BindDataToGrid(allRecords);
                return;
            }

            List<ClientRecord> filteredRecords = new List<ClientRecord>();

            if (searchCategory == "Company Name")
            {
                filteredRecords = allRecords.Where(r => r.CompanyName.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0).ToList();
            }
            else if (searchCategory == "Invoice No.")
            {
                if (int.TryParse(searchText, out int invoiceNumber))
                {
                    // Filtering invoice numbers that contain the typed text
                    filteredRecords = allRecords.Where(r => r.InvoiceNo.ToString().Contains(searchText)).ToList();
                }
                else
                {
                    MessageBox.Show("Please enter a valid invoice number.", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            else if (searchCategory == "By Date")
            {
                if (DateTime.TryParseExact(searchText, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime exactDate))
                {
                    filteredRecords = allRecords.Where(r => r.Date.Date == exactDate.Date).ToList();
                }
                else if (DateTime.TryParseExact(searchText, "MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime monthYearDate))
                {
                    filteredRecords = allRecords.Where(r => r.Date.Month == monthYearDate.Month && r.Date.Year == monthYearDate.Year).ToList();
                }
                else
                {
                    MessageBox.Show("Please enter a valid date in MM/dd/yyyy or MM/yyyy format.", "Invalid Date Format", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            if (filteredRecords.Count == 0)
            {
                MessageBox.Show("No records found.", "Search Result", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

            // Bind filtered records to grid
            BindDataToGrid(filteredRecords);
        }
    }

    public class ClientRecord
    {
        public int InvoiceNo { get; set; }
        public string CompanyName { get; set; }
        public DateTime Date { get; set; }

        public ClientRecord(int invoiceNo, string companyName, string date)
        {
            InvoiceNo = invoiceNo;
            CompanyName = companyName;
            Date = DateTime.ParseExact(date, "MM/dd/yyyy", CultureInfo.InvariantCulture);
        }
    }
}
